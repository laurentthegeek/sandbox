package study.jpa;

import java.util.ArrayList;
import java.util.List;
import jpa.common.ISOCountryCode;
import jpa.project.Project;
import jpa.project.Customer;
import jpa.common.Country;
import jpa.project.Address;
import jpa.project.Task;
import jpa.project.Worker;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import jpa.tree.Leaf;
import jpa.tree.Node;
import jpa.tree.Record;
import jpa.tree.Root;
import static org.junit.Assert.*;

public class AppTest {

    private static EntityManagerFactory emf;
    private static EntityManager em;
    private EntityTransaction tx;

    @BeforeClass
    public static void setUpClass() throws Exception {
        emf = Persistence.createEntityManagerFactory("mypu1");
        em = emf.createEntityManager();

    }

    @AfterClass
    public static void tearDownClass() throws Exception {
        em.close();
        emf.close();
    }

    @Before
    public void setUp() {
        tx = em.getTransaction();
    }

    @After
    public void tearDown() {
        if (tx.isActive()) {
            tx.rollback();
        }
    }

    private Country addCountry() {
        Country c = new Country();
        c.setName("France");
        c.setCountryCode(ISOCountryCode.FRA);
        em.persist(c);

        return c;
    }

    private Customer addCustomer() {
        Address a = new Address();
        a.setStreet("156 avenue Malakoff");
        a.setCity("Paris");
        a.setCountryCode(ISOCountryCode.FRA);

        Customer c = new Customer();
        c.setFirstname("John");
        c.setLastname("Customer");
        c.setAddress(a);
        em.persist(c);
        assertNotNull(c.getId());

        return c;
    }

    private Project addProject() {
        Project p = new Project();
        p.setTitle("Project 1");
        em.persist(p);
        assertNotNull(p.getId());
        assertNull(p.getTasks()); // TODO check whether the EM shouldn't have initialized this list?

        return p;
    }

    private Task addTask() {
        Task t = new Task();
        t.setName("Task 1");
        t.setWorkTime(10);
        em.persist(t);
        assertNotNull(t.getId());
        assertNull(t.getWorkers()); // TODO check whether the EM shouldn't have initialized this list?

        return t;
    }

    private Worker addWorker() {
        Address a = new Address();
        a.setStreet("111 powndermill rd");
        a.setCity("Maynard");
        a.setCountryCode(ISOCountryCode.USA);

        Worker w = new Worker();
        w.setFirstname("John");
        w.setLastname("Doe");
        w.setAddress(a);
        em.persist(w);

        return w;
    }

    @Test
    public void testEntities() {
        System.out.println("testEntities");

        tx.begin();

        addCountry();
        addCustomer();
        addProject();
        addTask();
        addWorker();

        tx.commit();
    }

    @Test
    public void testRelationships() {
        System.out.println("testRelationships");

        tx.begin();

        final int MAX = 3;

        Customer[] customers = new Customer[MAX];
        for (int i = 0; i < MAX; ++i) {
            customers[i] = addCustomer();
        }

        Worker[] workers = new Worker[MAX];
        for (int i = 0; i < MAX; ++i) {
            workers[i] = addWorker();
        }

        for (int i = 0; i < MAX; ++i) {
            Project p = new Project();
            p.setTitle("Project " + i);
            p.setCustomer(customers[i]);
            em.persist(p); // TODO should it be done first or last ?

            for (int j = 0; j < MAX; ++j) {
                Task t = new Task();
                t.setName(String.format("Task %d/%d", i, j));
                t.setWorkTime(i * j); // some dumb value
                t.addWorker(workers[j]);
                p.addTask(t);
            }
        }

        tx.commit();
    }

    @Test
    public void testInheritance() {
        System.out.println("testInheritance");

        tx.begin();

        Root root = new Root();
        em.persist(root);
        root.setName("Root");

        final int NODE_MAX = 10;
        final int LEAF_MAX = 10;

        List<Node> branches = new ArrayList();
        for (int i = 1; i <= NODE_MAX; ++i) {

            Node b = new Node();
            em.persist(b);
            b.setName("Node " + i);
            b.setParent(root);

            List<Node> leafs = new ArrayList(); // Java compiler error if List<Leaf>
            for (int j = 1; j <= LEAF_MAX; ++j) {

                Leaf l = new Leaf();
                em.persist(l);
                l.setName(String.format("Leaf %d/%d", i, j));
                l.setParent(b);
                leafs.add(l);
            }

            b.setChildren(leafs);
            branches.add(b);
        }

        root.setChildren(branches);

        tx.commit();
    }

    private int CountNodes(Node node) {
        int count = 1; // this node

        // plus any children
        if (node.getChildren() != null) {
            for (Node n : node.getChildren()) {
                count += CountNodes(n);
            }
        }

        return count;
    }

    @Test
    public void testNamedQueries() {
        System.out.println("testNamedQueries");

        Query q = em.createNamedQuery(Node.FIND_BY_NAME);
        q.setParameter("name", "Root");
        Root root = (Root) q.getSingleResult();
        assertEquals(111, CountNodes(root));
    }

    @Test
    public void testPolymorphicRelationship() {
        System.out.println("testPolymorphicRelationship");

        tx.begin();

        Leaf l = new Leaf();
        em.persist(l);
        l.setName("Leaf polymorphic 1");

        Record r = new Record();
        em.persist(r);
        r.setName("Record 1");
        r.setLeaf(l);

        tx.commit();


    }
}
