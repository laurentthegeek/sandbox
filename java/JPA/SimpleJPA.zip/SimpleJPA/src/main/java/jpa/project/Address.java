package jpa.project;

import jpa.common.ISOCountryCode;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable
@Access(AccessType.FIELD) // TODO check best practices
public class Address {

    private String street;
    private String city;
    @Enumerated(EnumType.STRING)
    private ISOCountryCode countryCode; // TODO add integrity  constraint w/ Country table

    @Override
    public String toString() {
        return String.format("Address: %s, %s, %s", getStreet(), getCity(), getCountryCode());
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public ISOCountryCode getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(ISOCountryCode code) {
        this.countryCode = code;
    }
}
