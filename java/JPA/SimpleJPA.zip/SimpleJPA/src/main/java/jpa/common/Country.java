package jpa.common;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

@Entity
@Access(AccessType.FIELD)
public class Country {

    @Id
    @Enumerated(EnumType.STRING)
    private ISOCountryCode countryCode;
    private String name;

    @Override
    public String toString() {
        return String.format("Country[%s]: %s", countryCode, name);
    }

    public ISOCountryCode getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(ISOCountryCode countryCode) {
        this.countryCode = countryCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
