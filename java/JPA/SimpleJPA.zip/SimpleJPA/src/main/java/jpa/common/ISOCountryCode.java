package jpa.common;

public enum ISOCountryCode {

    FRA,
    GBR,
    USA
}
